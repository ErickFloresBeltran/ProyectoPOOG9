
package ec.edu.espol.model;
import java.util.ArrayList;

public class Registrar {
    protected String nombres;
    protected String apellidos;
    protected String organizacion;
    protected String correoelectronico;
    protected String clave;
    
    public Registrar(String nombres,String apellidos,String organizacion,String correoelectronico,String clave){
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.organizacion = organizacion;
        this.correoelectronico = correoelectronico;
        this.clave = clave;      
    }
    
    
    
    
    
    
}

