
package ec.edu.espol.proyecto;

import ec.edu.espol.model.Vendedor;


public class Main {

    public static void main(String[] args) {
        
        Vendedor v1;
        
        
        
    }
    
}
