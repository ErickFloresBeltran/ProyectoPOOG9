
package ec.edu.espol.model;


public class Comprador extends Registrar{
    
    public Comprador(String nombres,String apellidos,String organizacion,String correoelectronico,String clave){
        super(nombres,apellidos,organizacion,correoelectronico,clave);
    }
    
    
    
    
}
