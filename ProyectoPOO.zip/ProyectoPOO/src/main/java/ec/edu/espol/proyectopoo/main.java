/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espol.proyectopoo;

import ec.edu.espol.model.Comprador;
import ec.edu.espol.model.Registrar;
import static ec.edu.espol.model.Registrar.getSHA;
import static ec.edu.espol.model.Registrar.toHexString;
import ec.edu.espol.model.Vehiculo;
import ec.edu.espol.model.Vendedor;
import ec.edu.espol.model.util;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Jara-Cadena
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vehiculo V1=null;
        ArrayList<String> placas= util.leerPlacas();
        ArrayList<String> marcas= util.leerMarca();
        ArrayList<String> modelos= util.leerModelos();
        ArrayList<String> motores= util.leerMotor();
        ArrayList<String> precio= util.leerPrecio();
            
    Scanner Sc= new Scanner(System.in);
    Sc.useLocale(Locale.US);
    int Opcion = 0;
    while(Opcion!=3){
        System.out.println(" ");
        System.out.println("Menu");
        System.out.println("1.Vendedor");
        System.out.println("2.Comprador");
        System.out.println("3.Salir");

      Opcion = Sc.nextInt();
      if (Opcion==1){
        int OpcionVendedor=0;
        while(OpcionVendedor!=4){
            if (OpcionVendedor==4)
                break;
            if (OpcionVendedor==1){
                 Registrar r = Registrar.leerteclado(Sc);
                ArrayList<String> correos = Registrar.leercorreos("listadevendedores.txt"); // de este .txt se crea la lista
                int a = 0;
                for (String i: correos){
                    if(r.getCorreoelectronico().equals(i)){
                        a=1;
                    }
                } 
                if (a==0){  
                    r.registrarVendedor();
                }          
                else
                  System.out.println("Este correo electronico ya esta registrado");  
            
            
            }
            if (OpcionVendedor==2){
                 ArrayList<String> claves = Registrar.leerclaves("listadevendedores.txt"); 
                System.out.println("Ingrese su corrreo: ");
                String correo = Sc.next();
                System.out.println("Ingrese su clave: ");
                String clave;
                try {
                    clave = toHexString(getSHA(Sc.next()));
                    int b = 0;
                    for(String c : claves){
                        if(c.equals(clave)){
                            b=1;
                        }
                    }
                    if (b==1){  
                    V1 = Vehiculo.LeerTeclado(Sc);
                    int a = 0;
                    for (String i:placas){
                        if(V1.getPlaca().equals(i)){
                        a=1;
                        }
                    }
                
                    if (a==0)
                        V1.registrarVehiculo();
                    else
                        System.out.println("Esa placa ya existe");
                        break;
                    }
                    
                    else
                    System.out.println("Esta clave es incorrecta");
                    
                } 
                catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (OpcionVendedor==3){
                    util.AceptarOferta("");                 
                    break;
            }
            else{
                System.out.println(" ");
                System.out.println("1.Registrar un nuevo vendedor");
                System.out.println("2.Ingresar nuevo vehiculo");
                System.out.println("3.Aceptar oferta");
                System.out.println("4.Regresar");
                OpcionVendedor=Sc.nextInt();
                //break;
            }

        }
      
        }
      if(Opcion==2){
        int OpcionComprador=0;
        while(OpcionComprador!=3){
            if (OpcionComprador==3)
                break;
             if (OpcionComprador==1){
                Registrar usuario = Registrar.leerteclado(Sc);
                ArrayList<String> compradores = util.leerEmails("Compradores.txt");
                int a = 0;
                
                for (String i : compradores){
                    if (i.equals(usuario.getCorreoelectronico()))
                        a = 1;
                    else
                        a = 0;
                }
                
                if (a == 1){
                    System.out.println("Ya existe un usuario vinculado a ese correo electronico");
                    break;
                }
                else{
                    usuario.registrarComprador();
                    break;
                }
            }
            
            else if (OpcionComprador==2){
                Comprador.mostrarOfertas(Sc);
                break;
            }
            else{
                System.out.println(" ");
                System.out.println("1.Registrar un nuevo comprador");             
                System.out.println("2.Ofertar por un vehiculo");
                System.out.println("3.Regresar");
                OpcionComprador=Sc.nextInt();
            //break;
            }

      }
      }
     

      }
      
        //System.out.println("  ");
        //System.out.println(placas);
        //System.out.println(marcas);
        //System.out.println(modelos);
        //System.out.println(motores);
        //System.out.println(precio);
        
        
        //util.realizarOferta("hola");
        
        //System.out.println(placas.get(1));
        //System.out.println(marcas.get(1)+" "+modelos.get(1)+" "+motores.get(1)+" Precio: "+precio.get(1));
        //System.out.println("Se han realizado 3 ofertas");
        //System.out.println("Correo: jperez@gmail.com " +" Precio Ofertado: 15500");
        
        
        
        
        
       
       
    }
    
}
