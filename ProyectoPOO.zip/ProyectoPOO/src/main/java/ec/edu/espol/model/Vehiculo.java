/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espol.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author Jara-Cadena
 */
    public  class Vehiculo {
    	private String Placa;
	private String Marca;
	private String Modelo;
	private double tipomotor;
	private int Año;
	private Double Recorrido;
	private String Color;
	private String Tipocombustible;
	private int Vidrios;
	private String Transmision;
	private String Traccion;
	private double Precio;
        private String TipoVehiculo;

    public String getMarca() {
        return Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public double getTipomotor() {
        return tipomotor;
    }

    public int getAño() {
        return Año;
    }

    public Double getRecorrido() {
        return Recorrido;
    }

    public String getColor() {
        return Color;
    }

    public String getTipocombustible() {
        return Tipocombustible;
    }

    public int getVidrios() {
        return Vidrios;
    }

    public String getTransmision() {
        return Transmision;
    }

    public String getTraccion() {
        return Traccion;
    }

    public double getPrecio() {
        return Precio;
    }

    public String getTipoVehiculo() {
        return TipoVehiculo;
    }

        
        
   
   
    public Vehiculo(String TipoVehiculo,String Placa,String Marca,String Modelo,double tipomotor,int Año,double Recorrido,String Color,String Tipocombustible,double Precio){
        this.Placa=Placa;
        this.Marca=Marca;
        this.Modelo=Modelo;
        this.tipomotor=tipomotor;
        this.Año=Año;
        this.Recorrido=Recorrido;
        this.Color=Color;
        this.Tipocombustible=Tipocombustible;
        this.Precio=Precio;
        this.TipoVehiculo=TipoVehiculo;
 
    
    }
    
    
     public Vehiculo(String TipoVehiculo,String Placa,String Marca,String Modelo,double tipomotor,int Año,double Recorrido,String Color,String Tipocombustible,int Vidrios,String Transmision,double Precio){
        this.Placa=Placa;
        this.Marca=Marca;
        this.Modelo=Modelo;
        this.tipomotor=tipomotor;
        this.Año=Año;
        this.Recorrido=Recorrido;
        this.Color=Color;
        this.Tipocombustible=Tipocombustible;
        this.Precio=Precio;
        this.Vidrios=Vidrios;
        this.Transmision=Transmision;
        this.TipoVehiculo=TipoVehiculo;
        
    }
    
        
    public Vehiculo(String TipoVehiculo,String Placa,String Marca,String Modelo,double tipomotor,int Año,double Recorrido,String Color,String Tipocombustible,String Traccion,int Vidrios,String Transmision,double Precio){
        this.Placa=Placa;
        this.Marca=Marca;
        this.Modelo=Modelo;
        this.tipomotor=tipomotor;
        this.Año=Año;
        this.Recorrido=Recorrido;
        this.Color=Color;
        this.Tipocombustible=Tipocombustible;
        this.Precio=Precio;
        this.Vidrios=Vidrios;
        this.Transmision=Transmision;
        this.Traccion=Traccion;
        this.TipoVehiculo=TipoVehiculo;
      
    
    
    }

    public String getPlaca() {
        return Placa;
    }
    
    
    
    
     
    
    public static Vehiculo LeerTeclado(Scanner SC){
        System.out.println("Ingrese el tipo de vehiculo: ");
        String TipoVehiculo;
        TipoVehiculo= SC.next();
        System.out.println("Ingrese la placa:");
        String Placa=SC.next();
        System.out.println("Ingrese la marca:");
        String Marca=SC.next();
        System.out.println("Ingrese el modelo:");
        String Modelo=SC.next();
        System.out.println("Ingrese el tipo de motor:");
        double Tipomotor=SC.nextDouble();
        while(Tipomotor<0 || Tipomotor>8.0){
            System.out.println("Ingrese correctamente el tipo de motor");
            Tipomotor=SC.nextDouble();
        }
            
        System.out.println("Ingrese el año del vehiculo:");
        int Año=SC.nextInt();
        while(Año<1900 || Año>2022){
            System.out.println("Ingrese correctamente el año");
            Año=SC.nextInt();
        }
        System.out.println("Ingrese el recorrido:");
        double Recorrido=SC.nextDouble();
        while(Recorrido<0){
            System.out.println("Ingrese correctamente el recorrido");
            Recorrido=SC.nextDouble();
        }
        
        System.out.println("Ingrese el color:");
        String Color=SC.next();
        System.out.println("Ingrese el tipo de combustible:");
        String TipoCombustible=SC.next();
        System.out.println("Ingrese el precio:");
        double Precio=SC.nextDouble();
        while(Precio<0){
            System.out.println("Ingrese correctamente el precio");
            Precio=SC.nextDouble();
        }
        
        
        
        if (TipoVehiculo.toLowerCase().equals("auto")){
            System.out.println("Ingrese la cantidad de ventanas:");
            int Vidrios=SC.nextInt();
            while(Vidrios<0 || Vidrios>8){
                System.out.println("Ingrese correctamente el numero de ventanas");
                Vidrios=SC.nextInt();
            }
            System.out.println("Ingrese el tipo de transmision:");
            String Transmision=SC.next();
            
        return new Vehiculo(TipoVehiculo,Placa,Marca,Modelo,Tipomotor,Año,Recorrido,Color,TipoCombustible,Vidrios,Transmision,Precio);
        
        }
        if (TipoVehiculo.toLowerCase().equals("camioneta")){
            System.out.println("Ingrese la cantidad de ventanas:");
            int Vidrios=SC.nextInt();
            while(Vidrios<0 || Vidrios>8){
                System.out.println("Ingrese correctamente el numero de ventanas");
                Vidrios=SC.nextInt();
            }
            System.out.println("Ingrese el tipo de transmision:");
            String Transmision=SC.next();
            System.out.println("Ingrese el tipo de traccion:");
            String Traccion=SC.next();
            
        return new Vehiculo(TipoVehiculo,Placa,Marca,Modelo,Tipomotor,Año,Recorrido,Color,TipoCombustible,Traccion,Vidrios,Transmision,Precio);
        
        }
        else
        return new Vehiculo(TipoVehiculo,Placa,Marca,Modelo,Tipomotor,Año,Recorrido,Color,TipoCombustible,Precio);
  
    }
    
    
     public void registrarVehiculo(){
         if(this.TipoVehiculo.toLowerCase().equals("moto")){
            try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("listavehiculos.txt"),true))){
                pw.println(this.TipoVehiculo+"|"+this.Placa+"|"+this.Marca+"|"+this.Modelo+"|"+this.tipomotor+"|"+this.Año+"|"+this.Recorrido+"|"+this.Color+"|"+this.Tipocombustible+"|"+this.Precio+"|"+0+"|"+0+"|"+0);
            }

            catch(Exception e){
                System.out.println(e.getMessage());
            }
         }
         
         if(this.TipoVehiculo.toLowerCase().equals("auto")){
            try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("listavehiculos.txt"),true))){
                pw.println(this.TipoVehiculo+"|"+this.Placa+"|"+this.Marca+"|"+this.Modelo+"|"+this.tipomotor+"|"+this.Año+"|"+this.Recorrido+"|"+this.Color+"|"+this.Tipocombustible+"|"+this.Precio+"|"+this.Vidrios+"|"+this.Transmision+"|"+0);
            }

            catch(Exception e){
                System.out.println(e.getMessage());
            }
         }
         
         
         if(this.TipoVehiculo.toLowerCase().equals("camioneta")){
            try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("listavehiculos.txt"),true))){
               pw.println(this.TipoVehiculo+"|"+this.Placa+"|"+this.Marca+"|"+this.Modelo+"|"+this.tipomotor+"|"+this.Año+"|"+this.Recorrido+"|"+this.Color+"|"+this.Tipocombustible+"|"+this.Precio+"|"+this.Vidrios+"|"+this.Transmision+"|"+this.Traccion);
            }

            catch(Exception e){
                System.out.println(e.getMessage());
            }
         }
         
    }
     
     
     
      public static ArrayList<String> leerPlacas(){
        ArrayList<String> placas = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                placas.add(tokens[1]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return placas;
    }
     
  
     
     
        
    public static ArrayList<Vehiculo> leerMotos(){
        ArrayList<Vehiculo> motos = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                Vehiculo moto = new Vehiculo(tokens[0],tokens[1],tokens[2],tokens[3],Integer.parseInt(tokens[4]),Integer.parseInt(tokens[5]),Double.parseDouble(tokens[6]),tokens[7],tokens[8],Double.parseDouble(tokens[9]));
                motos.add(moto);
            }
        }

        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return motos;
    }
     
    public static ArrayList<Vehiculo> leerAutos(){
        ArrayList<Vehiculo> autos = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                Vehiculo auto = new Vehiculo(tokens[0],tokens[1],tokens[2],tokens[3],Integer.parseInt(tokens[4]),Integer.parseInt(tokens[5]),Double.parseDouble(tokens[6]),tokens[7],tokens[8],Integer.parseInt(tokens[9]),tokens[10],Double.parseDouble(tokens[11]));
                autos.add(auto);
            }
        }

        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return autos;
    }
    
    public static ArrayList<Vehiculo> leerCamionetas(){
        ArrayList<Vehiculo> camionetas = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                Vehiculo camioneta = new Vehiculo(tokens[0],tokens[1],tokens[2],tokens[3],Integer.parseInt(tokens[4]),Integer.parseInt(tokens[5]),Double.parseDouble(tokens[6]),tokens[7],tokens[8],tokens[9],Integer.parseInt(tokens[10]),tokens[11],Double.parseDouble(tokens[12]));
                camionetas.add(camioneta);
            }
        }

        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return camionetas;
    }
       
    
    
    
    
    
    
    
    
  @Override
    public String toString(){
        if(this.TipoVehiculo.equals("moto"))
            return("Vehiculo: Moto"+" Placa:"+this.Placa+" Marca:"+this.Marca+" Modelo:"+this.Modelo+" Motor:"+this.tipomotor+" Año:"+this.Año+" Recorrido:"+this.Recorrido+" Color:"+this.Color+" Combustible:"+this.Tipocombustible+" Precio:"+this.Precio);
        if(this.TipoVehiculo.equals("auto"))
            return("Vehiculo: Auto"+" Placa:"+this.Placa+" Marca:"+this.Marca+" Modelo:"+this.Modelo+" Motor:"+this.tipomotor+" Año:"+this.Año+" Recorrido:"+this.Recorrido+" Color:"+this.Color+" Combustible:"+this.Tipocombustible+" Numero de ventanas"+this.Vidrios+" Tipo de transmision:"+this.Transmision+" Precio:"+this.Precio);
        else
            return("Vehiculo: Camioneta"+" Placa:"+this.Placa+" Marca:"+this.Marca+" Modelo:"+this.Modelo+" Motor:"+this.tipomotor+" Año:"+this.Año+" Recorrido:"+this.Recorrido+" Color:"+this.Color+" Combustible:"+this.Tipocombustible+" Numero de ventanas"+this.Vidrios+" Tipo de transmision:"+this.Transmision+" Tipo de traccion:"+this.Traccion+" Precio:"+this.Precio);
        
 
    }
    
    
   
    
    
}
