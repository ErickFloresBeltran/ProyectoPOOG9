/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espol.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Jara-Cadena
 */
public class util {
    
    private util(){}
    
    public static ArrayList<String> leerEmails(String nomfile){
        ArrayList<String> sistema = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(nomfile))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                sistema.add(tokens[2]);               
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return sistema;
    }

    
    
    
    
    
    public static ArrayList<String> leerPlacas(){
        ArrayList<String> placas = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                placas.add(tokens[1]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return placas;
    }
    
     public static ArrayList<String> leerMarca(){
        ArrayList<String> marcas = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                marcas.add(tokens[2]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return marcas;
    }
    
    
    
    
     public static ArrayList<String> leerModelos(){
        ArrayList<String> modelos = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                modelos.add(tokens[3]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return modelos;
    }
    
     
      public static ArrayList<String> leerMotor(){
        ArrayList<String> motores = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                motores.add(tokens[4]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return motores;
    }
    
     public static ArrayList<String> leerPrecio(){
        ArrayList<String> precios = new ArrayList<>();
        try (Scanner sc = new Scanner(new File("listavehiculos.txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                precios.add(tokens[9]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return precios;
    }

     
     public static ArrayList<String> leerOferta(String nomfile){
        ArrayList<String> ofertas = new ArrayList();
        try (Scanner sc = new Scanner(new File(nomfile+".txt"))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                ofertas.add("Correo: "+tokens[1]+"\n"+"Precio Ofertado: "+tokens[2]);
            }
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return ofertas;
    }
     
     
     
     
        
     public static void AceptarOferta(String str){
         Scanner Sc= new Scanner(System.in);
         System.out.println("Ingrese la placa:");
         String placaConsulta=Sc.next();
         ArrayList<String> placas= util.leerPlacas();
         ArrayList<String> marcas= util.leerMarca();
         ArrayList<String> modelos= util.leerModelos();
         ArrayList<String> motores= util.leerMotor();
         ArrayList<String> precio= util.leerPrecio();
         int indice=-1;
         for (int indiceInd = 0; indiceInd < placas.size();indiceInd++ ){
            if(placas.get(indiceInd).equals(placaConsulta)){
            indice=indiceInd;
            }
         }
         if (indice==-1){
             System.out.println("Esa placa no existe");
         
         }
         else{
            System.out.println(" ");
            System.out.println("Su placa es: "+placas.get(indice));
            System.out.println(marcas.get(indice)+" "+modelos.get(indice)+" "+motores.get(indice)+" Precio: "+precio.get(indice));
         }
        
         
         ArrayList Ofertas =util.leerOferta(placaConsulta);
         //System.out.println(Ofertas);
         
         
         int Opcion=0;
         
         int size=Ofertas.size();
         /*
         for(Object i:Ofertas ){
                 System.out.println(i);
                 System.out.println("1.- Siguiente Oferta");
                 System.out.println("2.- Aceptar Oferta");
                 Opcion=Sc.nextInt();
                 if (Opcion==2){
                     break;      
                 }
                 else
                     continue;
             
             }
         
         */
        
         for (int index=0;index<size;){
             System.out.println(Ofertas.get(index));
             System.out.println("1.- Aceptar Oferta");
             if(index<size-1)
                System.out.println("2.- Siguiente Oferta");
             
             
             if(index>0)
                 System.out.println("3.- Anterior Oferta");   
             
                 
             Opcion=Sc.nextInt();
             if (Opcion==1){
                 System.out.println("Usted ha aceptado la oferta ");
                     break;      
                 }
             if (Opcion==3)
                 index--;
             //if (Opcion<0)
             //    Opcion=0;
             
             else
                 index++;
         
         
         
         }
         
         
         
         
        
         
     
     }
     
     
     public static void realizarOferta(String nomfile){
        Scanner sc = new Scanner(System.in);
        double precio_oferta = sc.nextDouble();
        String correo_ofertor = sc.next();
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File(nomfile + ".txt"),true))){
            pw.println(nomfile+"|"+correo_ofertor+"|"+precio_oferta);
        }

        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
     
     
    
}
