
package ec.edu.espol.model;

import static ec.edu.espol.model.Registrar.getSHA;
import static ec.edu.espol.model.Registrar.toHexString;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;


public class Vendedor extends Registrar{
    
    public Vendedor(String nombres,String apellidos,String organizacion,String correoelectronico,String clave){
        super(nombres,apellidos,organizacion,correoelectronico,clave);  
        
    }   
    
      // añadir el nuevo vendedor al .txt de vendedores
   public void registrarVendedor(){
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("listadevendedores.txt"),true))){
            pw.println(this.nombres+"|"+this.apellidos+"|"+this.organizacion+"|"+this.correoelectronico+"|"+toHexString(getSHA(this.clave)));  
        }      
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
   
    

    
 

}
