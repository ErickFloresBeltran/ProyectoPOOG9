
package ec.edu.espol.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class Comprador extends Registrar{
    
    public Comprador(String nombres,String apellidos,String organizacion,String correoelectronico,String clave){
        super(nombres,apellidos,organizacion,correoelectronico,clave);
    }
    
    // CONVERSION DE CLAVE STRING A HASH CODE
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
	{
		// Static getInstance method is called with hashing SHA
		MessageDigest md = MessageDigest.getInstance("SHA-256");

		// digest() method called
		// to calculate message digest of an input
		// and return array of byte
		return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}
	
	public static String toHexString(byte[] hash)
	{
		// Convert byte array into signum representation
		BigInteger number = new BigInteger(1, hash);

		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));

		// Pad with leading zeros
		while (hexString.length() < 32)
		{
			hexString.insert(0, '0');
		}

		return hexString.toString();
	}
    
    
    
    public void realizarOferta(String nomfile){
        Scanner sc = new Scanner(System.in);
        double precio_oferta = sc.nextDouble();
        String correo_ofertor = sc.next();
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File(nomfile + ".txt"),true))){
            pw.println(nomfile+"|"+correo_ofertor+"|"+precio_oferta);
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void mostrarOfertas(Scanner sc){
        System.out.println("Ingrese el tipo de vehículo que desea buscar:");
        System.out.println("Para aquellos filtros que no desee ingresar de enter");
        System.out.println("Ingrese el tipo de vehículo que desee buscar");
        String tipoVehiculo = sc.nextLine();
        System.out.println("Ingrese el inicio del rango del recorrido");
        String recorridoInicio = sc.nextLine();
        System.out.println("Ingrese el fin del rango del recorrido");
        String recorridoFin = sc.nextLine();
        System.out.println("Ingrese el inicio del rango del año");
        String anioInicio = sc.nextLine();
        System.out.println("Ingrese el fin del rango del año");
        String anioFin = sc.nextLine();
        System.out.println("Ingrese el inicio del rango del precio");
        String precioInicio = sc.nextLine();
        System.out.println("Ingrese el fin del rango del precio");
        String precioFin = sc.nextLine();
        
        if (tipoVehiculo=="moto"){
            ArrayList<Vehiculo> motos = Vehiculo.leerMotos();
            ArrayList<Vehiculo> elementos = new ArrayList<>();
            for (Vehiculo i : motos){
                if(i.getRecorrido() >= Double.parseDouble(recorridoInicio) && i.getRecorrido() <= Double.parseDouble(recorridoFin)){
                    elementos.add(i);
                }
                else if (i.getAño() >= Integer.parseInt(anioInicio) && i.getAño() <= Integer.parseInt(anioFin)){
                    elementos.add(i);
                }
                else if (i.getPrecio() >= Double.parseDouble(precioInicio) && i.getPrecio() <= Double.parseDouble(anioFin)){
                    elementos.add(i);
                }
            }
            Set<Vehiculo> hashSet = new HashSet<Vehiculo>(elementos);
            elementos.clear();
            elementos.addAll(hashSet);
            System.out.println(elementos);
        }
        else if(tipoVehiculo=="auto"){
            ArrayList<Vehiculo> autos = Vehiculo.leerAutos();
            ArrayList<Vehiculo> elementos = new ArrayList<>();
            for (Vehiculo i : autos){
                if(i.getRecorrido() >= Double.parseDouble(recorridoInicio) && i.getRecorrido() <= Double.parseDouble(recorridoFin)){
                    elementos.add(i);
                }
                else if (i.getAño() >= Integer.parseInt(anioInicio) && i.getAño() <= Integer.parseInt(anioFin)){
                    elementos.add(i);
                }
                else if (i.getPrecio() >= Double.parseDouble(precioInicio) && i.getPrecio() <= Double.parseDouble(anioFin)){
                    elementos.add(i);
                }
            }
            Set<Vehiculo> hashSet = new HashSet<Vehiculo>(elementos);
            elementos.clear();
            elementos.addAll(hashSet);
            System.out.println(elementos);
        }
         else if(tipoVehiculo=="camioneta"){
            ArrayList<Vehiculo> camionetas = Vehiculo.leerCamionetas();
            ArrayList<Vehiculo> elementos = new ArrayList<>();
            for (Vehiculo i : camionetas){
                if(i.getRecorrido() >= Double.parseDouble(recorridoInicio) && i.getRecorrido() <= Double.parseDouble(recorridoFin)){
                    elementos.add(i);
                }
                else if (i.getAño() >= Integer.parseInt(anioInicio) && i.getAño() <= Integer.parseInt(anioFin)){
                    elementos.add(i);
                }
                else if (i.getPrecio() >= Double.parseDouble(precioInicio) && i.getPrecio() <= Double.parseDouble(anioFin)){
                    elementos.add(i);
                }
            }
            Set<Vehiculo> hashSet = new HashSet<Vehiculo>(elementos);
            elementos.clear();
            elementos.addAll(hashSet);
            System.out.println(elementos);
        }
    }
    
}
