
package ec.edu.espol.model;
import static ec.edu.espol.model.Comprador.getSHA;
import static ec.edu.espol.model.Comprador.toHexString;
import static ec.edu.espol.model.Vendedor.getSHA;
import static ec.edu.espol.model.Vendedor.toHexString;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Registrar {
    protected String nombres;
    protected String apellidos;
    protected String organizacion;
    protected String correoelectronico;
    protected String clave;
    
    public Registrar(String nombres,String apellidos,String organizacion,String correoelectronico,String clave){
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.organizacion = organizacion;
        this.correoelectronico = correoelectronico;
        this.clave = clave;    
    }
    
        
     // CONVERSION DE CLAVE STRING A HASH CODE
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
	{
            // Static getInstance method is called with hashing SHA
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // digest() method called
            // to calculate message digest of an input
            // and return array of byte
            return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}
	
    public static String toHexString(byte[] hash){
	// Convert byte array into signum representation
	BigInteger number = new BigInteger(1, hash);

	// Convert message digest into hex value
	StringBuilder hexString = new StringBuilder(number.toString(16));

	// Pad with leading zeros
	while (hexString.length() < 32)
	{
            hexString.insert(0, '0');
	}

	return hexString.toString();
    }
     
    
    public void registrarComprador(){
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("Compradores.txt"),true))){
            pw.println(this.nombres+"|"+this.apellidos+"|"+this.correoelectronico+"|"+this.organizacion+"|"+toHexString(getSHA(this.clave)));
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

      
      // añadir el nuevo vendedor al .txt de vendedores
    public void registrarVendedor(){
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(new File("listadevendedores.txt"),true))){
            pw.println(this.nombres+"|"+this.apellidos+"|"+this.organizacion+"|"+this.correoelectronico+"|"+toHexString(getSHA(this.clave)));  
        }      
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    
    
      // retorna lista de correos
    public static ArrayList<String> leercorreos(String nomfile){
        ArrayList<String> sistemadecorreos = new ArrayList<>();
        try(Scanner sc = new Scanner(new File(nomfile))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                sistemadecorreos.add(tokens[3]);
            } 
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return sistemadecorreos;
    }
    
      // retorna lista de claves en HASHCODE
    public static ArrayList<String> leerclaves(String nomfile){
        ArrayList<String> sistemadecorreos = new ArrayList<>();
        try(Scanner sc = new Scanner(new File(nomfile))){
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                String[] tokens = linea.split("\\|");
                sistemadecorreos.add(tokens[4]);
            } 
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return sistemadecorreos;
    }

    
        
    public static Registrar leerteclado(Scanner sc){
        System.out.println("Ingrese sus nombres: ");
        String nombres = sc.next();
        System.out.println("Ingrese sus apellidos: ");
        String apellidos = sc.next();
        System.out.println("Ingrese la organización en la que trabaja: ");
        String organizacion = sc.next();
        System.out.println("Ingrese su correo electronico: "); //correo
        String correoelectronico = sc.next();
        System.out.println("Ingrese su clave de usuario: ");
        String clave = sc.next(); 
        Registrar resultado = new Registrar(nombres,apellidos,organizacion,correoelectronico,clave);
        return resultado;
    }
    
  
  
    
 
    public String getNombres() {
        return nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getOrganizacion() {
        return organizacion;
    }

    public String getCorreoelectronico() {
        return this.correoelectronico;
    }

    public String getClave() {
        return clave;
    }
    
    
}
   


